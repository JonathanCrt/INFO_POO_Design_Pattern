package fr.uge.poo.paint.ex9;

public enum EColor {
    BLACK, WHITE, ORANGE;
}

package fr.uge.poo.paint.ex9;

@FunctionalInterface
public interface MouseCallback {
    void waitOnClick(int x, int y);
}

package fr.uge.poo.paint.ex8;

public enum EColor {
    BLACK, WHITE, ORANGE;
}

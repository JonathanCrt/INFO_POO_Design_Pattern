package fr.uge.poo.paint.ex8;

public interface CanvasFactory {
    Canvas createCanvas(int widthWindow, int heightWindow);
}

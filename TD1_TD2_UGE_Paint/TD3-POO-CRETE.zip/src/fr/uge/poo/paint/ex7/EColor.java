package fr.uge.poo.paint.ex7;

public enum EColor {
    BLACK, WHITE, ORANGE;
}

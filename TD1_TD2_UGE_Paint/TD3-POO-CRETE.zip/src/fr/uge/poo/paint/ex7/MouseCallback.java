package fr.uge.poo.paint.ex7;

@FunctionalInterface
public interface MouseCallback {
    void waitOnClick(int x, int y);
}
